import React, { useRef, useEffect, useState } from 'react';
import * as THREE from 'three';
import Lighting from './Lighting';
import SceneLoader from './SceneLoader';
import Camera from './Camera';
import VisibilitySwitch from '../UI/VisibilitySwitch';
import Indications from '../UI/Indications';

const Peniche: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [scenesVisibility, setScenesVisibility] = useState<boolean[]>([false, false, false, true, false, false, false]);
  const [indicationsVisibility, setIndicationsVisibility] = useState<boolean>(false);

  const camera = useRef<THREE.PerspectiveCamera>(new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000));
  const renderer = useRef<THREE.WebGLRenderer>(new THREE.WebGLRenderer());
  const scene = useRef<THREE.Scene>(new THREE.Scene());

  useEffect(() => {
    const container = containerRef.current;

    if (container) {
      renderer.current.setSize(container.clientWidth, container.clientHeight);
      container.appendChild(renderer.current.domElement);
    }
    
    return () => {
      if (container) {
        container.removeChild(renderer.current.domElement);
      }
    };
  }, []);

  useEffect(() => {
    camera.current.aspect = window.innerWidth / window.innerHeight;
    camera.current.updateProjectionMatrix();
    renderer.current.setSize(window.innerWidth, window.innerHeight);
  }, [window.innerWidth, window.innerHeight]);

  return (
    <div ref={containerRef} style={{ width: '100%', height: '100%' }}>
      <Lighting scene={scene.current} />
      <SceneLoader scene={scene.current} />
      <Camera camera={camera.current} />

      <VisibilitySwitch
        scenesVisibility={scenesVisibility}
        setScenesVisibility={setScenesVisibility}
        indicationsVisibility={indicationsVisibility}
        setIndicationsVisibility={setIndicationsVisibility}
      />

      <Indications indicationsVisibility={indicationsVisibility} /> {/* Ajout du composant Indications */}

      {/* Reste du code pour les boutons, gestion de la visibilité, etc. */}
    </div>
  );
};

export default Peniche;
