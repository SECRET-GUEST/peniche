import React, { useEffect } from 'react';
import * as THREE from 'three';
import { GLTF, GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

interface SceneLoaderProps {
  scene: THREE.Scene;
}

const SceneLoader: React.FC<SceneLoaderProps> = ({ scene }) => {
  useEffect(() => {
    const mainPenicheScenes = ['bas.glb', 'etage.glb', 'fond.glb', 'murs.glb', 'plafond.glb'];

    mainPenicheScenes.forEach((sceneUrl) => {
      const loader = new GLTFLoader();
      loader.load(
        `/assets/models/peniche/${sceneUrl}`,
        (gltf: GLTF) => {
          console.log(`Loaded 3D model: ${sceneUrl}`);
          scene.add(gltf.scene);
        },
        undefined,
        (error: unknown) => {
          console.error(`Error loading 3D model ${sceneUrl}:`, error);
        }
      );
    });

    const scenes = ['scene1.glb', 'scene2.glb', 'scene3.glb', 'scene4.glb', 'scene5.glb', 'scene6.glb', 'scene7.glb'];

    scenes.forEach((sceneUrl, index) => {
      const loader = new GLTFLoader();
      loader.load(
        `/assets/models/scenes/${sceneUrl}`,
        (gltf: GLTF) => {
          if (index === 3) {
            console.log(`Loaded 3D model: ${sceneUrl}`);
            scene.add(gltf.scene);
          } else {
            gltf.scene.visible = false;
            scene.add(gltf.scene);
          }
        },
        undefined,
        (error: unknown) => {
          console.error(`Error loading 3D model ${sceneUrl}:`, error);
        }
      );
    });

    const indicationsLoader = new GLTFLoader();
    indicationsLoader.load(
      '/assets/models/indications.glb',
      (gltf: GLTF) => {
        console.log('Loaded 3D model: indications.glb');
        gltf.scene.visible = false;
        scene.add(gltf.scene);
      },
      undefined,
      (error: unknown) => {
        console.error('Error loading 3D model indications.glb:', error);
      }
    );
  }, [scene]);

  return null;
};

export default SceneLoader;
