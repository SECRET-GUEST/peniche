import React, { useEffect } from 'react';
import * as THREE from 'three';

interface LightingProps {
  scene: THREE.Scene;
}

const Lighting: React.FC<LightingProps> = ({ scene }) => {
  useEffect(() => {
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.01);
    scene.add(ambientLight);

    const redSpotLight = new THREE.SpotLight(0x907060, 10);
    redSpotLight.position.set(-0.091, 3.333, 1.661);
    redSpotLight.angle = 1.571;
    scene.add(redSpotLight);

    scene.fog = new THREE.FogExp2(0xff0000, 0.028);


  }, [scene]);

  return null;
};

export default Lighting;
