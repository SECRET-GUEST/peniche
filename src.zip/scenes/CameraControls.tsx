import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import VisibilitySwitch from '../UI/VisibilitySwitch';

const CameraControls: React.FC = () => {
  const controls = useRef<OrbitControls | null>(null);

  useEffect(() => {
    controls.current = new OrbitControls(new THREE.PerspectiveCamera(), new THREE.WebGLRenderer().domElement);

    return () => {
      if (controls.current) {
        controls.current.dispose();
      }
    };
  }, []);

  return (
    <>
      <VisibilitySwitch 
        scenesVisibility={[]} 
        setScenesVisibility={() => {}} 
        indicationsVisibility={false} 
        setIndicationsVisibility={() => {}}
      />
    </>
  );
};

export default CameraControls;
