import React, { useEffect } from 'react';
import * as THREE from 'three';

interface CameraProps {
  camera: THREE.PerspectiveCamera;
}

const Camera: React.FC<CameraProps> = ({ camera }) => {
  useEffect(() => {
    camera.position.set(4, 1.3, 0);
    camera.rotation.set(
      THREE.MathUtils.degToRad(-0.73),
      THREE.MathUtils.degToRad(1.45),
      THREE.MathUtils.degToRad(0.73)
    );
  }, [camera]);

  return null;
};

export default Camera;
