import React from 'react';

interface VisibilitySwitchProps {
  scenesVisibility: boolean[];
  setScenesVisibility: React.Dispatch<React.SetStateAction<boolean[]>>;
  indicationsVisibility: boolean;
  setIndicationsVisibility: React.Dispatch<React.SetStateAction<boolean>>;
}

const VisibilitySwitch: React.FC<VisibilitySwitchProps> = ({
  scenesVisibility,
  setScenesVisibility,
  setIndicationsVisibility
}) => {
  const toggleSceneVisibility = (index: number) => {
    setScenesVisibility((prevVisibility) => {
      const newVisibility = [...prevVisibility];
      newVisibility[index] = !newVisibility[index];
      return newVisibility;
    });
  };

  const toggleIndicationsVisibility = () => {
    setIndicationsVisibility((prevVisibility) => !prevVisibility);
  };

  return (
    <>
      {scenesVisibility.map((_, index) => (
        <button key={index} onClick={() => toggleSceneVisibility(index)}>
          Toggle Scene {index + 1} Visibility
        </button>
      ))}

      <button onClick={toggleIndicationsVisibility}>Toggle Indications Visibility</button>
    </>
  );
};

export default VisibilitySwitch;
