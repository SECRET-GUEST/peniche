import React from 'react';

interface IndicationsProps {
  indicationsVisibility: boolean;
}

const Indications: React.FC<IndicationsProps> = ({ indicationsVisibility }) => {
  return (
    <div style={{ position: 'absolute', top: '108px', left: '10px', zIndex: 1 }}>
      {indicationsVisibility && (
        <div>
          <p>Indications are visible.</p>
        </div>
      )}
    </div>
  );
};

export default Indications;
