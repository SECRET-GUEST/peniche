import Peniche from './scenes/Peniche';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Peniche/>
      </header>
    </div>
  );
}

export default App;
